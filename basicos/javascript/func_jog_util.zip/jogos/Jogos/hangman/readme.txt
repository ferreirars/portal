Hangman Script by Jan Mulder.
For help or feedback visit: http://janmulder.com/contact/

This script is free under the terms of the GNU General Public License. 
You may use it as-is or modify it to suit your needs.
Please put an acknowledgement to me (see above) somewhere in the head section
of your page source. Some visible acknowledgement, while not necessary, is
customary and would be nice.

This script has been written from the ground up so
DO NOT COPY IT AND PASS IT OFF AS YOUR OWN.

To see how to use it view the source code for "index.html" and
the example files.
