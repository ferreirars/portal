-------
! ABOUT
-------

JsTetris is a tetris clone written in javascript, css, html. It only requires a browser to run. Tested on: IE, Mozilla, Opera.

Author: Cezary Tomczak (cagret at gmail.com)
Web site: http://www.gosu.pl/tetris/

You can subscribe to new releases here: http://freshmeat.net/projects/jstetris

This script can be used freely as long as all copyright messages are intact.

-----------
! CHANGELOG
-----------

*** 1.17 ***

  - Grid lines added
  - All blocks have different colors
  - Slight look changes

*** 1.10 ***
  - added Highscores module
  - playing board is centerd on the page
  - clicking "new game" or "reset" automatically closes help window