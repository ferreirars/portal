//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
/*
Esta funcion devuelve el objeto con el id pasado por argumento.
*/
//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
function get(d){
	return document.getElementById(d);
}