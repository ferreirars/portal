Title: Javascript Functions Library
Description: A recopilation of the best FREE Javascript functions. Over 38+ functions in Javascript including Len, Asc, Chr, Trim, LTrim, RTrim, Replace, strConv, Left, Right and much much more! Cross Browser Compatible too!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=1907&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
