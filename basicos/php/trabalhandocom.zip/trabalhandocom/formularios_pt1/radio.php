<?php
echo "Seu sistema operacional �: " . $_POST["sistema"];
echo "<br>Seu monitor �: " . $_POST["monitor"];
?>