-- Criar banco: pdo_simples

create table clientes(
	id int primary key auto_increment,
    nome varchar(32),
    email varchar(50)
);
insert into clientes(nome, email) values ('Ribamar FS', 'ribafs@gmail.com');
insert into clientes(nome, email) values ('F�tima EF', 'fatima@gmail.com');
insert into clientes(nome, email) values ('Tiago EF', 'tiago@gmail.com');
insert into clientes(nome, email) values ('Elias EF', 'elias@gmail.com');
