<?php
require_once('pdo_simples.php');

// Criando uma inst�ncia
$pdo = new pdoSimples();

// Criemos pequenos trechos de c�digo para testar cada uma das fun��es da classe.
// Ap�s testar cada uma comentamos seu c�digo para n�o interferir no resultado

// Insert
//$nome='Jo�o Brito';
//$email='joao@joao.com';
//$pdo->insert($nome,$email);

// Update
// $id=5;
// $nome='Jo�o Brito Cunha';
// $email='joao@joao.com';
// $pdo->update($id,$nome,$email);

// Select
//$select = $pdo->select();
//print '<pre>';
//var_dump($select);
//print '</pre>';

// SelectOne
// $id=5;
// $select=$pdo->selectOne($id);
//print '<pre>';
//var_dump($select);
//print '</pre>';

// Delete
$id=10;
$pdo->delete($id);
	