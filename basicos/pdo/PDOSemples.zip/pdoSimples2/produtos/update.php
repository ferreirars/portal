<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <title>Edit Data - PDO</title>
 </head>
<body>

<?php
function __autoload($class){
	include_once('../'.$class.".php");	
}

//require_once('../pdoSimples.php');

$obj=new pdoSimples();

if(isset($_REQUEST['update'])){
 extract($_REQUEST);

 $update="UPDATE produtos SET nome=:nome,valor=:valor WHERE id=:id";
 $execute=array(':id'=>$id,':nome'=>$nome,':valor'=>$valor);

 if($obj->update($update,$execute)){
	header("location:index.php?status=success");
 }
}
extract($obj->selectOne($_REQUEST['id'],"produtos"));
echo <<<show
 <a href="index.php">Início</a>
 <h3>Editar Produto</h3>
 <form action="update.php" method="post">
 <table width="500" border="1">
 <tr>
 <th scope="row">Id</th>
 <td><input type="text" name="id" value="$id" readonly="readonly"></td>
 </tr>
 <tr>
 <th scope="row">Nome</th>
 <td><input type="text" name="nome" value="$nome"></td>
 </tr>
 <tr>
 <tr>
 <th scope="row">Valor</th>
 <td><input type="text" name="valor" value="$valor"></td>
 </tr>
 <tr>
 <th scope="row">&nbsp;</th>
 <td><input type="submit" name="update" value="Atualizar"></td>
 </tr>
 </table>
 </form>
</div>
show;
?>
</body>
</html>
