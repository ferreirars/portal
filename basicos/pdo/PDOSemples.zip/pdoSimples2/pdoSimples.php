<?php
// Esta versão da classe suporta várias tabelas com apenas uma cópia
class pdoSimples{
	private $host = 'localhost';
	private $dbname = 'pdo_simples';
	private $user = 'root';
	private $pass = '';
	private $DBH;
	private $STH;

	public function __construct(){
		try {
		  $this->DBH = new PDO("mysql:host=".$this->host.";dbname=".$this->dbname,$this->user,$this->pass);
		  $this->DBH->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
		} catch(PDOException $e) {
			echo 'Erro: '.$e->getMessage();
		}
	}
	// A função update() serve para insert e update. Muda apenas os parâmetros. Exemplo de uso para ambos:
	// $insert="INSERT INTO produtos SET nome=:nome,valor=:valor"; e $execute=array(':nome'=>$nome,':valor'=>$valor);
	// $obj->update($insert,$execute);
	
	// $update="UPDATE produtos SET nome=:nome,valor=:valor WHERE id=:id"; e $execute=array(':id'=>$id,':nome'=>$nome,':valor'=>$valor);
	// $obj->update($update,$execute);

	function update($prepare,$execute){
		$STH = $this->DBH->prepare($prepare);
		$STH->execute($execute);
		return true;
	}

	public function select($table){
		$sql="SELECT * FROM $table";
		$q = $this->DBH->query($sql) or die("failed!");
		
		while($r = $q->fetch(PDO::FETCH_ASSOC)){
			$data[]=$r;
		}
		return $data;
	}

	public function selectOne($id,$table){
		$sql="SELECT * FROM $table WHERE id = :id";
		$q = $this->DBH->prepare($sql);

		$q->execute(array(':id'=>$id));
		$data = $q->fetch(PDO::FETCH_ASSOC);
		return $data;
	}

	public function delete($id,$table){
		$sql="DELETE FROM $table WHERE id=:id";
		$q = $this->DBH->prepare($sql);
		$q->execute(array(':id'=>$id));
		return true;
	}
}
// Esta pequena classe foi inspirada neste tutorial
// http://www.w3programmers.com/crud-with-pdo-and-oop-php/