<?php
require_once ("includes/pdoCrud.php");

$codigo = $_POST['codigo'];
$nome = $_POST['nome'];

$objCrud = new pdoCrud();
$objCrud->insert('Ricardo Miranda', "cliente");
?>
