<?php
require_once ("includes/pdoCrud.php");

$objCrud = new pdoCrud();

$codigo=$_GET['codigo'];
$tabela = 'cliente';

$objCrud->delete($codigo,$tabela);
?>
