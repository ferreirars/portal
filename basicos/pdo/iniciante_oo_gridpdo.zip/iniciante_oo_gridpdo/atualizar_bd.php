<?php
require_once ("includes/pdoCrud.php");

$codigo = $_POST['codigo'];
$nome = $_POST['nome'];
$tabela = 'cliente';
$objCrud = new pdoCrud();
$objCrud->update($codigo, $nome,$tabela);
print "<a href='index.php'>Voltar</a>";
?>
