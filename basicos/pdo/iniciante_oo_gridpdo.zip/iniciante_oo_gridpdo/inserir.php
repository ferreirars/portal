<?php
require_once ("includes/template.class.php");

$objMenu = new template();

print $objMenu->form(array("codigo", "nome"), "inserir_bd.php", "frmInserir", "POST");
print $objMenu->getRodape();

?>
