<?php

class template
{
    private $menu = '<center><b>Aplicativo Iniciante em PHPOO - Menu Principal</b><br><br></center>';
	private $form = '';
	private $cabecalho = '<html><head><title>Aplicativo Iniciante usando PHPOO</title>
				<body bgcolor="lightgray"><h1 align="center">Aplicativo Iniciante usando PHPOO</h1><hr align="center">';
	private $rodape = '<br><br><br><center><hr align="center"><b><i>Desenvolvimento de Aplicativos em PHP</b></i></center></body>';

	function __construct()
	{
		print $this->cabecalho;
	}

	public function getRodape()
	{
		return $this->rodape;
	}

	public function setRodape($rodape)
	{
		$this->rodape = $rodape;
	}

	public function setCabecalho($cabecalho)
	{
		$this->cabecalho = $cabecalho;
	}

	/** Método menu
	  * @method menu
	  * @param string[] $arquivos_nomes
	  * @example array('inserir.php', 'consultar.php', 'atualizar.php', 'excluir.php');	  
	  * @return $this->menu
	  */  		

	public function menu ($scripts=array())
	{		
		reset($scripts);
		$this->menu ='<center><table border="0"> ';
		while (list($chave, $arquivo) = each ($scripts)) {
    		$this->menu .= '<tr><td><a href='.$arquivo.'>'.$arquivo.'</a></td></tr>';
		}
		$this->menu .='</table></center>';		
		return $this->menu;
	}

	/** Método form
	  * @method form
	  * @param string[] $campos_nomes
	  * @example array('codigo', 'nome') , 'inserir.php', 'frmInserir', 'POST');	  
	  * @return void
	  */  		

	public function form ($campos=array(), $acao, $nome, $metodo)
	{		
		reset($campos);
		$this->form .= "<center><table border=\"0\">\n";
		$this->form .= "<form name=\"$nome\" action=\"$acao\" method=\"$metodo\"><br />\n";

		while (list($chave, $campo) = each ($campos)) {
    		$this->form .= "<tr><td>$campo</td><td><input type=\"text\" name=\"$campo\" value=\"\"></td></tr>\n";
		}
			$this->form .= "<tr><td>&nbsp;</td><td colspan=\"2\"><input type=\"submit\" value=\"Enviar\">\n";
			$this->form .= "&nbsp;<input type=\"reset\" value=\"Limpar\"></td></tr>\n";
			$this->form .= "</form>\n";
			$this->form .= "</table></center>\n";
			$this->form .= "<center><br><br><a href='index.php'>Voltar ao Menu</a></center>\n";
			return $this->form;
	}
}
?>
