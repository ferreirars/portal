-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Gera��o: Fev 20, 2007 as 07:25 PM
-- Vers�o do Servidor: 5.0.27
-- Vers�o do PHP: 5.2.0
-- 
-- Banco de Dados: `iniciante`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `cliente`
-- 

CREATE TABLE `cliente` (
  `codigo` int(11) NOT NULL,
  `nome` varchar(45) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Extraindo dados da tabela `cliente`
-- 

INSERT INTO `cliente` VALUES (1, 'Ribamar FS2');
INSERT INTO `cliente` VALUES (3, 'Tiago EF');
INSERT INTO `cliente` VALUES (4, 'Roberto Pontes');
INSERT INTO `cliente` VALUES (2, 'Lima Jr');