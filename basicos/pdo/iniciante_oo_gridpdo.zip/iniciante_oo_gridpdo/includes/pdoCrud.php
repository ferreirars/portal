<?php

class pdoCrud{
 private $host="localhost";
 private $user="root";
 private $db="iniciante";
 private $pass="";
 private $conn;

 public function __construct(){
	$this->conn = new PDO("mysql:host=".$this->host.";dbname=".$this->db,$this->user,$this->pass);
 }

 public function select($table){
	$sql="SELECT * FROM $table";
	$q = $this->conn->query($sql) or die("failed!");
	
	while($r = $q->fetch(PDO::FETCH_ASSOC)){
		$data[]=$r;
	}
	return $data;
}

 public function selectOne($codigo,$table){
	$sql="SELECT * FROM $table WHERE codigo = :codigo";
	$q = $this->conn->prepare($sql);
	$q->execute(array(':codigo'=>$codigo));
	$data = $q->fetch(PDO::FETCH_ASSOC);
	return $data;
 }

 public function update($codigo,$nome,$table){
	$sql = "UPDATE $table SET nome=:nome WHERE codigo=:codigo";
	$q = $this->conn->prepare($sql);
	$q->execute(array(':codigo'=>$codigo,':name'=>$name));
	return true;
 }

 public function insert($nome,$table){
	$sql = "INSERT INTO $table SET nome=:nome";
	$q = $this->conn->prepare($sql);
	$q->execute(array(':nome'=>$nome));
	return true;
 }

 public function delete($codigo,$table){
	$sql="DELETE FROM $table WHERE codigo=:codigo";
	$q = $this->conn->prepare($sql);
	$q->execute(array(':codigo'=>$codigo));
	return true;
 }
}
// Cr�dito
// http://www.w3programmers.com/crud-with-pdo-and-oop-php/
// Ver tamb�m: http://www.w3programmers.com/php-data-object-pdo-basic/
?>