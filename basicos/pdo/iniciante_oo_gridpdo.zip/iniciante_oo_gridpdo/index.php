<table border="1" align="center">
<?php
require_once ("includes/pdoCrud.php");
require_once ("includes/template.class.php");

$objMenu = new template();
$objCrud = new pdoCrud(); // Conectar com o banco
$regs = $objCrud->select("cliente");

foreach($regs as $chave => $valor){
	$nome = $valor['nome'];
	print "<form method=post action=atualizar_form.php>";
	print "Código<input name=codigo value=$chave><br>";
	print "Nome<input name=nome value='".$nome."'>";
	print "<input type=submit value=Enviar></form>";
	//$chave</td><td><a href=atualizar_form.php?codigo=$chave&nome='".$nome."'>$nome</a></td></tr>"; 	
}
print "<tr><td>&nbsp;</td><td><a href='inserir.php'>Novo Registro</a></td></tr>";
print "<table>";

print $objMenu->getRodape();
?>
