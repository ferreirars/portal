<?php
require_once ("includes/pdoCrud.php");
require_once ("includes/template.class.php");

$codigo=$_GET['codigo'];
$nome = $_GET['nome'];
$nome = $_POST['nome'];
$tabela = 'cliente';

$objMenu = new template();
$objCrud = new pdoCrud(); // Conectar com o banco
?>
<form action="atualizar_bd.php">
Código<input type="text" name="codigo" value="<?=$codigo?>"><br>
Nome<input type="text" name="nome" value="<?=$nome?>"><br>
<input type="submit" value="Atualizar">
</form>
<?php
print $objMenu->getRodape();	

?>
