<?php

class Quatro{
	public $classe="Quatro";
}
