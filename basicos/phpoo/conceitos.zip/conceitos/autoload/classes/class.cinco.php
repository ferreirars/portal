<?php

class Cinco{
public $classe="Cinco";
}
