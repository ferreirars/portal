<?php
	include 'Image.class.php';

	$thumb = new Thumbnail("image.jpg", 125, 100);
	$thumb->display();
?>